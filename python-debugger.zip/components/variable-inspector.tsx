"use client"

import { useState } from "react"
import { ChevronRight, ChevronDown } from "lucide-react"

interface VariableInspectorProps {
  variables: Record<string, any>
}

export default function VariableInspector({ variables }: VariableInspectorProps) {
  if (Object.keys(variables).length === 0) {
    return (
      <div className="p-4 bg-slate-800 rounded-md text-slate-400 min-h-[200px]">
        <p>Run your code to see variables here</p>
      </div>
    )
  }

  return (
    <div className="p-4 bg-slate-800 rounded-md min-h-[200px]">
      <table className="w-full text-sm">
        <thead className="text-left border-b border-slate-700">
          <tr>
            <th className="pb-2 font-semibold">Name</th>
            <th className="pb-2 font-semibold">Type</th>
            <th className="pb-2 font-semibold">Value</th>
          </tr>
        </thead>
        <tbody>
          {Object.entries(variables).map(([name, value]) => (
            <VariableRow key={name} name={name} value={value} />
          ))}
        </tbody>
      </table>
    </div>
  )
}

function VariableRow({ name, value }: { name: string; value: any }) {
  const [isExpanded, setIsExpanded] = useState(false)

  const type = typeof value
  const isExpandable = type === "object" && value !== null

  let displayValue = String(value)
  if (type === "object" && value !== null) {
    displayValue = isExpanded ? JSON.stringify(value, null, 2) : JSON.stringify(value)
  }

  return (
    <>
      <tr className="border-b border-slate-700">
        <td className="py-2 font-mono">{name}</td>
        <td className="py-2 text-emerald-400">{Array.isArray(value) ? "array" : type}</td>
        <td className="py-2 font-mono">
          {isExpandable ? (
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="inline-flex items-center text-blue-400 hover:text-blue-300"
            >
              {isExpanded ? <ChevronDown className="h-4 w-4 mr-1" /> : <ChevronRight className="h-4 w-4 mr-1" />}
              {Array.isArray(value) ? `Array(${value.length})` : `Object {${Object.keys(value).length} properties}`}
            </button>
          ) : (
            displayValue
          )}
        </td>
      </tr>
      {isExpanded && isExpandable && (
        <tr>
          <td colSpan={3} className="py-2 pl-8">
            <pre className="text-xs overflow-auto max-h-40 bg-slate-850 p-2 rounded">
              {JSON.stringify(value, null, 2)}
            </pre>
          </td>
        </tr>
      )}
    </>
  )
}
