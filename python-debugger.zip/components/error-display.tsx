export default function ErrorDisplay({ error }: { error: string | null }) {
  if (!error) {
    return (
      <div className="p-4 bg-slate-800 rounded-md text-slate-400 min-h-[200px]">
        <p>No errors detected</p>
      </div>
    )
  }

  // Parse error message to extract line number if available
  const lineMatch = error.match(/line (\d+)/)
  const lineNumber = lineMatch ? Number.parseInt(lineMatch[1], 10) : null

  return (
    <div className="p-4 bg-slate-800 rounded-md min-h-[200px]">
      <div className="flex items-center mb-2">
        <div className="h-4 w-4 rounded-full bg-red-500 mr-2"></div>
        <h3 className="font-semibold text-red-400">Error</h3>
      </div>

      {lineNumber && (
        <div className="mb-2 text-sm">
          <span className="text-slate-400">Line {lineNumber}</span>
        </div>
      )}

      <pre className="whitespace-pre-wrap text-red-300 font-mono text-sm bg-red-950/30 p-3 rounded border border-red-900">
        {error}
      </pre>

      <div className="mt-4 text-sm text-slate-400">
        <p>Common Python errors:</p>
        <ul className="list-disc pl-5 mt-1">
          <li>SyntaxError: Invalid syntax in your code</li>
          <li>NameError: Using a variable that hasn't been defined</li>
          <li>TypeError: Operation on incompatible types</li>
          <li>IndexError: Trying to access an index that doesn't exist</li>
          <li>IndentationError: Incorrect indentation</li>
        </ul>
      </div>
    </div>
  )
}
