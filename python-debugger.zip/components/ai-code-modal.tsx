"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Highlight, themes } from "prism-react-renderer"

interface AICodeModalProps {
  isOpen: boolean
  onClose: () => void
  generatedCode: string
  onApply: () => void
}

export default function AICodeModal({ isOpen, onClose, generatedCode, onApply }: AICodeModalProps) {
  const [activeTab, setActiveTab] = useState<string>("code")

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[800px] bg-slate-900 text-white border-slate-700">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <span className="text-purple-400">✨</span> AI Generated Alternative
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-2">
          <TabsList className="mb-4">
            <TabsTrigger value="code">Code</TabsTrigger>
            <TabsTrigger value="explanation">Explanation</TabsTrigger>
          </TabsList>

          <TabsContent value="code" className="mt-0">
            <div className="rounded-md border border-slate-700 overflow-hidden max-h-[400px] overflow-y-auto">
              <Highlight theme={themes.vsDark} code={generatedCode} language="python">
                {({ className, style, tokens, getLineProps, getTokenProps }) => (
                  <pre
                    className={`${className} p-4 overflow-auto text-sm`}
                    style={{ ...style, backgroundColor: "transparent" }}
                  >
                    {tokens.map((line, i) => (
                      <div key={i} {...getLineProps({ line, key: i })}>
                        <span className="inline-block w-8 text-right mr-2 text-slate-500 select-none">{i + 1}</span>
                        {line.map((token, key) => (
                          <span key={key} {...getTokenProps({ token, key })} />
                        ))}
                      </div>
                    ))}
                  </pre>
                )}
              </Highlight>
            </div>
          </TabsContent>

          <TabsContent value="explanation" className="mt-0">
            <div className="bg-slate-800 rounded-md p-4 max-h-[400px] overflow-y-auto">
              <h3 className="font-semibold mb-2">Code Improvements</h3>
              <ul className="list-disc pl-5 space-y-2 text-sm">
                <li>Improved algorithm efficiency with better time complexity</li>
                <li>Added proper error handling with try/except blocks</li>
                <li>Included input validation to prevent common errors</li>
                <li>Added helpful comments explaining the code logic</li>
                <li>Followed PEP 8 style guidelines for better readability</li>
              </ul>

              <h3 className="font-semibold mt-4 mb-2">Key Differences</h3>
              <p className="text-sm text-slate-300">
                The alternative implementation uses a more efficient approach that reduces computational complexity. It
                also includes better error handling and documentation to make the code more maintainable.
              </p>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter className="flex justify-between sm:justify-between">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={onApply} className="bg-purple-600 hover:bg-purple-700 text-white">
            Apply This Code
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
