export default function OutputDisplay({ output }: { output: string }) {
  if (!output) {
    return (
      <div className="p-4 bg-slate-800 rounded-md text-slate-400 min-h-[200px]">
        <p>Run your code to see output here</p>
      </div>
    )
  }

  return (
    <div className="p-4 bg-slate-800 rounded-md min-h-[200px]">
      <pre className="whitespace-pre-wrap font-mono text-sm">{output}</pre>
    </div>
  )
}
